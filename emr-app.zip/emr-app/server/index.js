// Server mock untuk latihan. Ganti dengan backend asli saat tersedia.
import express from 'express';

const app = express();
app.use(express.json());

const patients = {
  '88392': { name: 'Budi Santoso', bloodType: 'O+', status: 'Critical', allergies: ['Penisilin'] },
};
const seenKeys = new Map(); // Idempotency-Key -> respons pertama

app.get('/api/patients/:id', (req, res) => {
  const p = patients[req.params.id];
  if (!p) return res.status(404).json({ message: 'Pasien tidak ditemukan' });
  res.json(p);
});

app.post('/api/visits', (req, res) => {
  const key = req.get('Idempotency-Key');
  if (!key) return res.status(400).json({ message: 'Idempotency-Key wajib' });
  if (seenKeys.has(key)) return res.status(200).json(seenKeys.get(key)); // retry: jangan simpan ganda

  const { patientId, soap } = req.body ?? {};
  if (!patientId || !soap) return res.status(400).json({ message: 'Data tidak lengkap' });

  const saved = { id: `visit-${seenKeys.size + 1}`, ...req.body };
  seenKeys.set(key, saved);
  console.log('Kunjungan tersimpan:', saved);
  res.status(201).json(saved);
});

app.listen(3001, () => console.log('API mock di http://localhost:3001'));
