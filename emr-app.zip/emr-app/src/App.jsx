import PatientHeader from './components/PatientHeader';
import SoapForm from './components/SoapForm';

export default function App() {
  return (
    <main className="page">
      <PatientHeader patientId="88392" />
      <SoapForm />
    </main>
  );
}
