import { create } from 'zustand';
import { fetchPatient, submitVisit } from '../api/patients';

const emptyVitals = { systolic: '', diastolic: '', heartRate: '', temperature: '', spo2: '' };
const emptySoap = { subjective: '', objective: '', assessment: '', plan: '' };

// "Vault" sesi medis: satu sumber data untuk semua komponen (hindari prop-drilling).
export const usePatientStore = create((set, get) => ({
  activePatientId: null,
  patientData: null,
  vitals: { ...emptyVitals },
  soapDraft: { ...emptySoap },   // draft belum tersimpan, tidak hilang saat pindah komponen
  icd10: '',
  idempotencyKey: crypto.randomUUID(),
  loadStatus: 'idle',            // idle | loading | success | error
  submitStatus: 'idle',          // idle | loading | success | error
  error: null,

  loadPatient: async (patientId) => {
    set({ activePatientId: patientId, loadStatus: 'loading', error: null });
    try {
      const patientData = await fetchPatient(patientId);
      set({ patientData, loadStatus: 'success' });
    } catch (e) {
      set({ loadStatus: 'error', error: 'Gagal memuat data pasien.' });
    }
  },

  setVital: (field, value) => set((s) => ({ vitals: { ...s.vitals, [field]: value } })),
  setSoap: (field, value) => set((s) => ({ soapDraft: { ...s.soapDraft, [field]: value } })),
  setIcd10: (icd10) => set({ icd10 }),

  submit: async () => {
    const s = get();
    if (s.submitStatus === 'loading') return; // cegah submit ganda
    set({ submitStatus: 'loading', error: null });
    try {
      await submitVisit({
        patientId: s.activePatientId,
        vitals: s.vitals,
        soap: s.soapDraft,
        icd10: s.icd10,
        idempotencyKey: s.idempotencyKey,
      });
      set({
        submitStatus: 'success',
        soapDraft: { ...emptySoap },
        vitals: { ...emptyVitals },
        icd10: '',
        idempotencyKey: crypto.randomUUID(), // kunci baru untuk kunjungan berikutnya
      });
    } catch (e) {
      // kunci sama dipertahankan agar Retry tidak membuat catatan ganda
      set({ submitStatus: 'error', error: 'Gagal menyimpan. Periksa koneksi lalu coba lagi.' });
    }
  },
}));
