import DOMPurify from 'dompurify';
import { api } from './client';

// Teks polos: buang semua tag HTML sebelum dikirim.
// Backend tetap wajib memvalidasi ulang, jangan hanya mengandalkan frontend.
export const cleanText = (value) =>
  DOMPurify.sanitize(String(value ?? ''), { ALLOWED_TAGS: [], ALLOWED_ATTR: [] }).trim();

// GET /api/patients/:id
export async function fetchPatient(patientId, signal) {
  const { data } = await api.get(`/patients/${encodeURIComponent(patientId)}`, { signal });
  return data; // { name, bloodType, status, allergies, ... }
}

// POST /api/visits
// idempotencyKey mencegah rekam medis ganda jika tombol terklik dua kali atau request diulang.
export async function submitVisit({ patientId, vitals, soap, icd10, idempotencyKey }) {
  const payload = {
    patientId,
    icd10: cleanText(icd10),
    vitals: {
      systolic: Number(vitals.systolic) || null,
      diastolic: Number(vitals.diastolic) || null,
      heartRate: Number(vitals.heartRate) || null,
      temperature: Number(String(vitals.temperature).replace(',', '.')) || null,
      spo2: Number(vitals.spo2) || null,
    },
    soap: {
      subjective: cleanText(soap.subjective),
      objective: cleanText(soap.objective),
      assessment: cleanText(soap.assessment),
      plan: cleanText(soap.plan),
    },
  };
  const { data } = await api.post('/visits', payload, {
    headers: { 'Idempotency-Key': idempotencyKey },
  });
  return data;
}
