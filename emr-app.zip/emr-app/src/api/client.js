import axios from 'axios';

// Token JWT disimpan di HttpOnly cookie oleh backend (tidak terbaca JavaScript),
// jadi frontend cukup mengirim cookie otomatis lewat withCredentials.
export const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL ?? '/api',
  withCredentials: true,
  timeout: 10000,
  headers: { 'Content-Type': 'application/json' },
});

api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      window.location.assign('/login'); // sesi habis
    }
    return Promise.reject(err);
  }
);
