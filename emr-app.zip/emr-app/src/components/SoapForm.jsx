import { usePatientStore } from '../store/usePatientStore';

const SOAP_FIELDS = [
  ['subjective', 'S – Subjective'],
  ['objective', 'O – Objective'],
  ['assessment', 'A – Assessment'],
  ['plan', 'P – Plan'],
];
const VITAL_FIELDS = [
  ['systolic', 'Sistolik (mmHg)'],
  ['diastolic', 'Diastolik (mmHg)'],
  ['heartRate', 'Detak jantung (bpm)'],
  ['temperature', 'Suhu (°C)'],
  ['spo2', 'SpO₂ (%)'],
];

export default function SoapForm() {
  const { vitals, soapDraft, submitStatus, error, setVital, setSoap, submit } = usePatientStore();
  const loading = submitStatus === 'loading';

  return (
    <form onSubmit={(e) => { e.preventDefault(); submit(); }}>
      <fieldset disabled={loading}>
        <legend>Tanda vital</legend>
        {VITAL_FIELDS.map(([key, label]) => (
          <label key={key}>
            {label}
            <input value={vitals[key]} onChange={(e) => setVital(key, e.target.value)} />
          </label>
        ))}
      </fieldset>

      <fieldset disabled={loading}>
        <legend>Catatan SOAP</legend>
        {SOAP_FIELDS.map(([key, label]) => (
          <label key={key}>
            {label}
            <textarea value={soapDraft[key]} onChange={(e) => setSoap(key, e.target.value)} />
          </label>
        ))}
      </fieldset>

      {/* idle -> loading -> success/error */}
      <button type="submit" disabled={loading}>
        {loading ? 'Menyimpan…' : submitStatus === 'error' ? 'Coba lagi' : 'Simpan catatan'}
      </button>
      {submitStatus === 'success' && <p role="status">Berhasil disimpan ke EMR.</p>}
      {submitStatus === 'error' && <p role="alert">{error}</p>}
    </form>
  );
}
