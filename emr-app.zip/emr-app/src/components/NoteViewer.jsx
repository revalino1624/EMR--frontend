import DOMPurify from 'dompurify';

// Hanya untuk catatan rich-text dari server. Sanitasi SAAT RENDER.
// Untuk teks polos, cukup tampilkan {note} di JSX (React sudah meng-escape).
export default function NoteViewer({ note }) {
  return <div dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(note) }} />;
}
