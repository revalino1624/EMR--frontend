import { useEffect } from 'react';
import { usePatientStore } from '../store/usePatientStore';

export default function PatientHeader({ patientId }) {
  const { patientData, loadStatus, error, loadPatient } = usePatientStore();

  useEffect(() => { loadPatient(patientId); }, [patientId, loadPatient]);

  if (loadStatus === 'loading') return <p role="status">Memuat data pasien…</p>;
  if (loadStatus === 'error') {
    return (
      <div role="alert">
        {error} <button onClick={() => loadPatient(patientId)}>Coba lagi</button>
      </div>
    );
  }
  if (!patientData) return null;

  const critical = patientData.status === 'Critical';
  return (
    <header>
      <h1>{patientData.name}</h1>
      <span>Gol. darah {patientData.bloodType}</span>
      {/* Kode ganda: ikon + teks + warna, bukan warna saja */}
      <span role="status" style={{ background: critical ? '#991B1B' : '#14532D', color: '#fff' }}>
        {critical ? '⚠ KRITIS' : '✓ STABIL'}
      </span>
      {patientData.allergies?.map((a) => (
        <div key={a} role="alert" style={{ background: '#FFB020', color: '#1A1200' }}>
          ⚠ Alergi: {a}
        </div>
      ))}
    </header>
  );
}
