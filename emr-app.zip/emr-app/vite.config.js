import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    // Semua request /api diteruskan ke server mock di port 3001
    proxy: { '/api': 'http://localhost:3001' },
  },
});
