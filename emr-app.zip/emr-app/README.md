# EMR Frontend (React + Zustand + Axios)

Latihan Lab Practicum: frontend EMR dengan state management, integrasi API, dan sanitasi DOM.

## Menjalankan di VS Code
```bash
npm install
npm run dev:all    # frontend di http://localhost:5173, API mock di http://localhost:3001
```
Atau jalankan terpisah di dua terminal: `npm run dev` dan `npm run server`.

## Struktur
- `src/api/` Axios client + GET pasien / POST kunjungan (DOMPurify sebelum kirim)
- `src/store/` Zustand store (pasien aktif, tanda vital, draf SOAP, status submit)
- `src/components/` PatientHeader, SoapForm, NoteViewer
- `server/` API mock Express (dengan dukungan Idempotency-Key)

## Keamanan
- JWT sebaiknya di HttpOnly cookie, bukan `localStorage` (`withCredentials: true`).
- Sanitasi saat kirim dan saat render; backend tetap wajib memvalidasi.
